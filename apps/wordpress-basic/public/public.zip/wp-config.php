<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp4206978db_9407' );

/** MySQL database username */
define( 'DB_USER', 'wpdb9407u4894' );

/** MySQL database password */
define( 'DB_PASSWORD', 'wpdbsFsQFdauRq4Jzaj3p22039' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '&^fIx9;TK/YwUf$N= q9uTk:2e^4n^rC:Iq;y_^,&<|a;A[7K.}21,FF_0K1m-yh');
define('SECURE_AUTH_KEY',  'bJE*<u#|5QTtUfoSM#W)D2pSb=(s*@b61vPuskLiAC}PFMTmcBn}U3RQ&TD5-r,w');
define('LOGGED_IN_KEY',    'fkmD]%W+k`]Hx)_5+L-w=1V[YMoA3$YF7j&wc#O]p(H5#VU-qgM1O:XS0XQ)lA0)');
define('NONCE_KEY',        'p.VQ5WWZq#cjiPim)XDkZu!^(-y%W~Y3Mhlup!DL)%e^30XSe+VFHt?w|W)A+fJ2');
define('AUTH_SALT',        '-TJo78_6I>+|lf(zm#raVBg)5Cs^+3]O7T(b?/K=r.O[GKb* VMe|{h#G6y0/%4-');
define('SECURE_AUTH_SALT', '^=:>SQLog&{U@?D&lqyo?HS|#%HRZ#TLFghjjAh|oZ~VgpN(4~5FGy#u~$ Dsia(');
define('LOGGED_IN_SALT',   'Dk952_dV!o!wi2fdGa}KG&[7)+J=P|Y,]l6-_|c2+_`:9U3Lh?61gR46~!79[m=o');
define('NONCE_SALT',       'LSp7Y=B6 O6sWL-)^@:++s|zHf^,;5?>f|(eUJMl4EXN2lWKp@xh9-;<}G-|/j15');


/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = '908_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
